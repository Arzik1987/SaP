# bpriv
Smart-meter privacy algorithms and privacy measures
